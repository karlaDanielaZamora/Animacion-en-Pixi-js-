
// Textured Mesh Basic (Malla texturizada básica)

import { Assets, Point, Container, MeshRope } from 'https://cdn.skypack.dev/pixi.js';


export async function TBasic(app) {  

    
    // aqui se carga  la textura del fondo espacio para que el astronauta este adelante de la imagen 
    const spaceTexture = await Assets.load('./assets/espacio.jpg');
          
    // Cargar la textura de astronauta
    const texture = await Assets.load('./assets/aust.png');  
    let count = 0;

    // Construir la cuerda desde los puntos osea si alargarlo o no
    const ropeLength = 1000 / 13;
    const points = [];

    for (let i = 0; i < 20; i++) {
        points.push(new Point(i * ropeLength, 0));
    }

    // Aqui Creamos el MeshRope del astronauta
    const strip = new MeshRope({ texture, points });
    strip.x = -46;
    
    //aus es austrounata xd,
    const ausContainer = new Container(); // es para subirlo o bajarlo 
    ausContainer.x = 400;
    ausContainer.y = 200;

    ausContainer.scale.set(800 / 1100);

    // Agregar el austrounata después del fondo para que se dibuje encima
    app.stage.addChild(ausContainer);
    ausContainer.addChild(strip);

    // Animar los puntos de la cuerda
    app.ticker.add(() => {
        count += 0.1;

        // Hacer que el austrounata  se mueva
        for (let i = 1; i < points.length; i++) {
            points[i].y = Math.sin(i * 0.5 + count) * 10;
            points[i].x = i * ropeLength + Math.cos(i * 0.3 + count) * 100;
        }
    });
}


