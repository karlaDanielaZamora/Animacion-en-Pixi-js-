//AQUI METI LA IMAGEN DE LA LUCIERGANA Y METI LA IMAGEN ESPACIO YA QUE AQUI HAGO QUE LA LUCIERGANA PASEN ARRIBAA DE LA IMAGEN DEL ESPACIO
//rotacion,tinte,cambio de textutura,sonido esos me faltaban ya la maestra me corrigio 

import { MeshPlane, Assets, Sprite, Rectangle } from 'https://cdn.skypack.dev/pixi.js';

export async function Fond3(app) {
    // Cargar la textura de la imagen del espacio para que la luci pase adelante 
    const texture = await Assets.load('./assets/espacio.jpg');
    const alienTexture = await Assets.load('./assets/aliend.png');
    // Crear la primera instancia del plano (MeshPlane) con la textura
    const espacio1 = new MeshPlane({ texture, verticesX: 2, verticesY: 10 });

    // Posicionar y escalar la primera imagen
    espacio1.x = 0;
    espacio1.y = app.screen.height - espacio1.height * 0.6 - 29;
    espacio1.scale.set(0.3);

    // Agregar la primera imagen 
    app.stage.addChild(espacio1);

    // Crear la segunda instancia del plano (MeshPlane)
    const espacio2 = new MeshPlane({ texture, verticesX: 2, verticesY: 10 });
    espacio2.x = espacio1.x + espacio1.width * 1; // Justo al lado de la primera imagen
    espacio2.y = espacio1.y;
    espacio2.scale.set(0.3);

    // Agregar la segunda imagen al escenario
    app.stage.addChild(espacio2);

    // Obtener los buffers de los vértices para la animación
    const { buffer: buffer1 } = espacio1.geometry.getAttribute('aPosition');
    const { buffer: buffer2 } = espacio2.geometry.getAttribute('aPosition');

    // Cargar la textura de luciérnaga
    const lucierganaTexture = await Assets.load('./assets/luciergana.png');

    // Crear un array para almacenar las luciérnagas
    const luci = [];
    const totalLuci = 30;

    for (let i = 0; i < totalLuci; i++) {
        const luciergana = new Sprite(lucierganaTexture);
        luciergana.anchor.set(0.5);
        luciergana.scale.set(0.1);

        // Posición aleatoria inicial
        luciergana.x = Math.random() * app.screen.width;
        luciergana.y = Math.random() * app.screen.height;

        luciergana.direction = Math.random() * Math.PI * 2;
        luciergana.turningSpeed = Math.random() - 0.8;
        luciergana.speed = 2 + Math.random() * 2;

        luci.push(luciergana);
        app.stage.addChild(luciergana); // Añadir luciérnaga encima del fondo
    }

    // Crear un cuadro delimitador para las luciérnagas
    const boundsPadding = 100;
    const bounds = new Rectangle(
        -boundsPadding,
        -boundsPadding,
        app.screen.width + boundsPadding * 2,
        app.screen.height + boundsPadding * 2,
    );

    let timer = 0;


    // ESPACIO Y LUCI 
    app.ticker.add(() => {
        // Animar el fondo DEL ESPACIO
        for (let i = 0; i < buffer1.data.length; i++) {
            buffer1.data[i] += Math.sin(timer / 3 + i) * 0.7;
        }
        for (let i = 0; i < buffer2.data.length; i++) {
            buffer2.data[i] += Math.sin(timer / 3 + i) * 0.7;
        }
        buffer1.update();
        buffer2.update();

        // Animar las luciérnagas
        for (const luciergana of luci) {
            luciergana.direction += luciergana.turningSpeed * 0.01;
            luciergana.x += Math.sin(luciergana.direction) * luciergana.speed;
            luciergana.y += Math.cos(luciergana.direction) * luciergana.speed;
            luciergana.rotation = -luciergana.direction - Math.PI / 2;

            // Limitar las posiciones dentro de los límites
            if (luciergana.x < bounds.x) luciergana.x += bounds.width;
            else if (luciergana.x > bounds.x + bounds.width) luciergana.x -= bounds.width;

            if (luciergana.y < bounds.y) luciergana.y += bounds.height;
            else if (luciergana.y > bounds.y + bounds.height) luciergana.y -= bounds.height;
        }

        timer++;
    });
}





