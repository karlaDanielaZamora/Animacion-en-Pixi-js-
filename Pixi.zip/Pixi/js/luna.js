//IMGEN DE LOS CUADROS DE LOS MARCIANOS 


import { Assets, Sprite } from 'https://cdn.skypack.dev/pixi.js';

export async function CTextura(app) {
    // Cargar las texturas de los cuadros los marcianos xd
    const textures = [   
        await Assets.load('./assets/Cua1.jpg'),
        await Assets.load('./assets/Cuad2.jpg'),
        await Assets.load('./assets/Cuad3.jpg'),
        await Assets.load('./assets/Cuad4.jpg'),
        await Assets.load('./assets/Cuad5.jpg')
    ];
    
    let currentTextureIndex = 0; // Índice para controlar qué textura se muestra

    
    // Crear Sprite usando la primera textura y pasarlo al escenario
    const character = new Sprite(textures[currentTextureIndex]);

    // Cambiar tamaño del sprite
    character.scale.set(0.4); 


    // Movemos el sprite a la esquina derecha, EL OTRO ESQUINA DERECHA Y ES QUINA SUPERIOR 
    character.anchor.set(0.5); 
    character.x = app.screen.width - character.width / 2; 
    character.y = character.height / 2;

    // PARA QUES EVEA EL SPRITE A LA VISTA 
    app.stage.addChild(character);

    // Hacer que el sprite sea interactivo
    character.eventMode = 'static';
    character.cursor = 'pointer';

    // CAMBIA RCUANDO SE HAGA CLIC
    character.on('pointertap', () => {
        currentTextureIndex = (currentTextureIndex + 1) % textures.length; // CLICLO PARA LAS TEXTURA S
        character.texture = textures[currentTextureIndex];

    });
}




