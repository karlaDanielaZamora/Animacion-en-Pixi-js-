//IMAGEN DE LA ESTRELLA

import { Assets, Sprite } from 'https://cdn.skypack.dev/pixi.js';

export async function Star(app) {
    // Cargar la textura del fondo
    const texture = await Assets.load('./assets/espacio.jpg');
    // Cargar la textura de la estrella
    const starTexture = await Assets.load('./assets/star.png');

    // Conf inicial
    const starAmount = 500; // Cant de estrellas
    let cameraZ = 0; 
    const fov = 20; // en donde se pondra 
    const baseSpeed = 1; // Vel base del movimiento
    let speed = 0; // Vel actual
    let warpSpeed = 0; // Velocidad de "salto" o aceleración
    const starStretch = 60; // Factor de estiramiento de las estrellas
    const starBaseSize = 0.10; // Tamaño base de la estrellas

    // Crear las estrellas
    const stars = [];

    for (let i = 0; i < starAmount; i++) {
        const star = {
            sprite: new Sprite(starTexture), // Sprite de la estrella
            z: 0, //Z,X Y Y:  SON EJES 
            x: 0, 
            y: 0, 
        };

        star.sprite.anchor.x = 0.5; 
        star.sprite.anchor.y = 0.7; 
        randomizeStar(star, true); // Inicializar la posición de la estrella
        app.stage.addChild(star.sprite); // Agregar la estrella al escenario
        stars.push(star); // Añadir la estrella a la lista
    }

    // Función para posicionar aleatoriamente una estrella
    function randomizeStar(star, initial) {
        // Determinar posición inicial o nueva posición en Z
        star.z = initial ? Math.random() * 2000 : cameraZ + Math.random() * 1000 + 2000;

        // Calcular posiciones radiales aleatorias para evitar que las estrellas pasen por la cámara
        const deg = Math.random() * Math.PI * 2; // Ángulo en radianes
        const distance = Math.random() * 50 + 1; // Distancia radial

        star.x = Math.cos(deg) * distance; // Posición X
        star.y = Math.sin(deg) * distance; // Posición Y
    }

    // Cambiar la velocidad de vuelo cada 5 segundos
    setInterval(() => {
        warpSpeed = warpSpeed > 0 ? 0 : 1; // Alternar entre velocidad normal y acelerada
    }, 5000);

    // Actualizar animación en cada frame
    app.ticker.add((time) => {
        // Ajuste de velocidad con suavizado (easing)
        speed += (warpSpeed - speed) / 20;
        // Incrementar la posición de la cámara según la velocidad
        cameraZ += time.deltaTime * 10 * (speed + baseSpeed);

        for (let i = 0; i < starAmount; i++) {
            const star = stars[i];

            // Reposicionar la estrella si pasa la cámara
            if (star.z < cameraZ) randomizeStar(star);

            // Mapear la posición 3D de la estrella a 2D utilizando una proyección simple
            const z = star.z - cameraZ;

            star.sprite.x = star.x * (fov / z) * app.renderer.screen.width + app.renderer.screen.width / 2;
            star.sprite.y = star.y * (fov / z) * app.renderer.screen.width + app.renderer.screen.height / 2;

            // Calcular la escala y rotación de las estrellas
            const dxCenter = star.sprite.x - app.renderer.screen.width / 2; // Distancia al centro en X
            const dyCenter = star.sprite.y - app.renderer.screen.height / 2; // Distancia al centro en Y
            const distanceCenter = Math.sqrt(dxCenter * dxCenter + dyCenter * dyCenter); // Distancia al centro
            const distanceScale = Math.max(0, (2000 - z) / 2000); // Escala basada en la distancia

            star.sprite.scale.x = distanceScale * starBaseSize; // Escala en X
            // Ajustar la escala en Y dependiendo de la velocidad y el estiramiento
            star.sprite.scale.y
                = distanceScale * starBaseSize
                + (distanceScale * speed * starStretch * distanceCenter) / app.renderer.screen.width;
            // Ajustar la rotación de la estrella hacia el centro
            star.sprite.rotation = Math.atan2(dyCenter, dxCenter) + Math.PI / 2;
        }
    });
}



