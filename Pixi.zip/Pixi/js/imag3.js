//IMAGEN DEL ESPACIO 

import { MeshPlane, Assets } from 'https://cdn.skypack.dev/pixi.js';
 
export async function Fond2(app) {
    // Cargar la textura de la imagen
    
    const texture = await Assets.load('./assets/espacio.jpg');

    
    const espacio1 = new MeshPlane({ texture, verticesX: 12, verticesY: 10 });//  primera instancia del plano (MeshPlane) con la textura

    // Posicionar la primera imagen a la izquierda y moverla un poco hacia arriba
    espacio1.x = 0;  
    espacio1.y = app.screen.height - espacio1.height * 0.6 - 29;  

    
    // Reducir el tamaño de la primera imagen (ajustando la escala)
    espacio1.scale.set(0.3); 

    
    app.stage.addChild(espacio1);// Agregar la primera imagen 

    // Crear la segunda instancia del plano (MeshPlane) con la misma textura
    const espacio2 = new MeshPlane({ texture, verticesX: 2, verticesY: 10 });
    

    // Posicionar la segunda imagen justo al lado de la primera y moverla un poco hacia arriba
    espacio2.x = espacio1.x + espacio1.width * 1;  // Ajusta este valor para que se junten o superpongan
    espacio2.y = espacio1.y;  // Mantener la misma altura

    // Reducir el tamaño de la segunda imagen (ajustando la escala)
    espacio2.scale.set(0.3); 

    // Agregar la segunda imagen al escenario
    app.stage.addChild(espacio2);



    //AGRAGAMOS IMAGENES
    const espacio3 = new MeshPlane({ texture, verticesX: 2, verticesY: 10 });

    espacio3.x=espacio2.x + espacio2.width +1;
    espacio3.y=espacio2.y;

    espacio3.scale.set(0.3);
    app.stage.addChild(espacio3);

    const espacio4 = new MeshPlane({ texture, verticesX: 2, verticesY: 10 });

    espacio4.x=espacio3.x + espacio3.width +1;
    espacio4.y=espacio3.y;

    espacio4.scale.set(0.3);
    app.stage.addChild(espacio4);

    const espacio5 = new MeshPlane({ texture, verticesX: 2, verticesY: 10 });

    espacio5.x=espacio4.x + espacio4.width +1;
    espacio5.y=espacio4.y;

    espacio5.scale.set(0.3);
    app.stage.addChild(espacio5);

    const espacio6 = new MeshPlane({ texture, verticesX: 2, verticesY: 10 });

    espacio6.x=espacio5.x + espacio5.width +1;
    espacio6.y=espacio5.y;

    espacio6.scale.set(0.3);
    app.stage.addChild(espacio6);

    const espacio7 = new MeshPlane({ texture, verticesX: 2, verticesY: 10 });

    espacio7.x=espacio6.x + espacio6.width +1;
    espacio7.y=espacio6.y;

    espacio7.scale.set(0.3);
    app.stage.addChild(espacio7);

    const espacio8 = new MeshPlane({ texture, verticesX: 2, verticesY: 10 });

    espacio8.x=espacio7.x + espacio7.width +1;
    espacio8.y=espacio7.y;

    espacio8.scale.set(0.3);
    app.stage.addChild(espacio8);


    // Obtener el buffer de las posiciones de los vértices para la animación
    const { buffer: buffer1 } = espacio1.geometry.getAttribute('aPosition');
    const { buffer: buffer2 } = espacio2.geometry.getAttribute('aPosition');
    const { buffer: buffer3 } = espacio3.geometry.getAttribute('aPosition');
    const { buffer: buffer4 } = espacio4.geometry.getAttribute('aPosition');
    const { buffer: buffer5 } = espacio5.geometry.getAttribute('aPosition');
    const { buffer: buffer6 } = espacio6.geometry.getAttribute('aPosition');
    const { buffer: buffer7 } = espacio7.geometry.getAttribute('aPosition');
    const { buffer: buffer8 } = espacio8.geometry.getAttribute('aPosition');

    //  la actualización de la animación
    let timer = 10;

    app.ticker.add(() => {
        // Randomizar las posiciones de los vértices para crear movimiento en la primera imagen
        for (let i = 0; i < buffer1.data.length; i++) {
            buffer1.data[i] += Math.sin(timer / 3 + i) * 0.7;
        }

        for (let i = 0; i < buffer2.data.length; i++) {
            buffer2.data[i] += Math.sin(timer / 3 + i) * 0.7;
        }
        for(let i= 0; i< buffer3.data.length;i++){
            buffer3.data[i] +=Math.sin(timer / 3+i)* 0.7;
        }
        for(let i= 0; i< buffer4.data.length;i++){
            buffer4.data[i] +=Math.sin(timer / 3+i)* 0.7;
        }
        for(let i= 0; i< buffer5.data.length;i++){
            buffer5.data[i] +=Math.sin(timer / 3+i)* 0.7;
        }
        for(let i= 0; i< buffer6.data.length;i++){
            buffer6.data[i] +=Math.sin(timer / 3+i)* 0.7;
        }
        for(let i= 0; i< buffer7.data.length;i++){
            buffer7.data[i] +=Math.sin(timer / 3+i)* 0.7;
        }
        for(let i= 0; i< buffer8.data.length;i++){
            buffer8.data[i] +=Math.sin(timer / 3+i)* 0.7;
        }

        buffer1.update();
        buffer2.update();
        buffer3.update();
        buffer4.update();
        buffer5.update();
        buffer6.update();
        buffer7.update();
        buffer8.update();
        timer++;
    });
}





