
//Gato marciano  de la ceja levantada 
import { Assets, Sprite, SCALE_MODES } from 'https://cdn.skypack.dev/pixi.js';

export async function Fond1(app) {

    const texture = await Assets.load('./assets/espacio.jpg');

   /* // Crear el fondo del espacio como un Sprite POR SI QUIERO PONER EL FONDO DE ESPACIO EN EL LADO DEL 
    const background = new Sprite(spaceTexture);
    background.width = app.screen.width;
    background.height = app.screen.height;
    app.stage.addChild(background); // Añadir al escenario primero para que sea el fondo */

    // Cargar la textura del gato marciano 
    const Gtexture = await Assets.load('./assets/GatoMar.jpg');
    Gtexture.baseTexture.scaleMode = SCALE_MODES.NEAREST;

    // Crear múltiples gatos marcianos  en posiciones aleatorias
    for (let i = 0; i < 5; i++) {
        createGato(Math.floor(Math.random() * app.screen.width), Math.floor(Math.random() * app.screen.height));
    }

    function createGato(x, y) {
        // Crear el sprite del gato marciano 
        const Gato = new Sprite(Gtexture);

        // Configurar propiedades del gato marciano 
        Gato.anchor.set(0.5);
        Gato.scale.set(0.1); //TAMAÑO DEL GATO MARCIANO 
        Gato.x = x;
        Gato.y = y;

        // Hacer que EL GATO MARCIANO  sea interactiva
        Gato.eventMode = 'static';
        Gato.cursor = 'pointer';

        // CUANDO VEMOS EL CUADRO DEL GATO SE PUEDA MOVER U  ARRASTRAR
        Gato.on('pointerdown', onDragStart);
        app.stage.addChild(Gato); // Añadir al escenario
    }

    let dragTarget = null;

    // Configurar eventos  de arrastre
    app.stage.eventMode = 'static';
    app.stage.hitArea = app.screen;
    app.stage.on('pointerup', onDragEnd);
    app.stage.on('pointerupoutside', onDragEnd);

    function onDragStart(event) {
        dragTarget = event.currentTarget;
        dragTarget.alpha = 0.5; // Reducir opacidad mientras se arrastra
        app.stage.on('pointermove', onDragMove);
    }

    function onDragMove(event) {
        if (dragTarget) {
            const newPosition = event.global;
            dragTarget.x = newPosition.x;
            dragTarget.y = newPosition.y;
        }
    }

    function onDragEnd() {
        if (dragTarget) {
            dragTarget.alpha = 1; // Restaurar opacidad
            dragTarget = null;
            app.stage.off('pointermove', onDragMove);
        }
    }
}


