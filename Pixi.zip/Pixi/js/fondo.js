//aqui solo agregamos un fondo azul y un rectangulo negro 

import { Graphics} from 'https://cdn.skypack.dev/pixi.js';

export function crearFondo(app) {
    // Crear el fondo azul  para que se vea bonito 
    const fondo = new Graphics();
    fondo.beginFill(0x002A5E);
    fondo.drawRect(0, 0, app.screen.width, app.screen.height); 
    fondo.endFill();

    // Agregar el fondo al escenario
    app.stage.addChild(fondo);

    // Crear un rectángulo negro como piso
    const rectangleHeight = 400; // Altura del rectángulo aqui muevo la altura de mi pantalla
    const rectangle = new Graphics();
    rectangle.beginFill(0x000000); // Color negro 
    rectangle.drawRect(0, app.screen.height - rectangleHeight, app.screen.width, rectangleHeight); // Pasamos hacia abajo 
    rectangle.endFill();

    // Agregamos  el rectángulo para verlo 
    app.stage.addChild(rectangle);
}




