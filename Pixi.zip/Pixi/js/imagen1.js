//movemos el mago en el fondo 

import { Sprite, Assets } from 'https://cdn.skypack.dev/pixi.js';

export async function crearPersonaje(app) {
    try {
        const texture = await Assets.load('./assets/espacio.jpg');
        const textura = await Assets.load('./assets/mago.PNG');
        
        // Crear sprite del  que es el mago
        const Mago = new Sprite(textura);

        // Configurar el tamaño del sprite directamente a scala
        Mago.scale.set(0.5); // Reduce el tamaño a la mitad

        // Configurar posición inicial
        Mago.x = app.screen.width / 2 - Mago.width / 2;
        Mago.y = app.screen.height / 2 - Mago.height / 2;

        // hacer aparecer el sprite a la pantalla 
        app.stage.addChild(Mago);

        // Manejamos el movimiento con las teclas
        const velocidad = 5;
        const teclas = {};

        // Función para actualizar y mover  la posición del Mago
        function moverMago() {
            if (teclas['ArrowUp'] && Mago.y > 0) {
                Mago.y -= velocidad; //arriba
            }
            if (teclas['ArrowDown'] && Mago.y < app.screen.height - Mago.height) {
                Mago.y += velocidad; // abajo
            }
            if (teclas['ArrowLeft'] && Mago.x > 0) {
                Mago.x -= velocidad; //izq
            }
            if (teclas['ArrowRight'] && Mago.x < app.screen.width - Mago.width) {
                Mago.x += velocidad; // derecha
            }
        }

        // aquie es que detecte las teclas cuando le pico 
        window.addEventListener('keydown', (e) => {
            teclas[e.key] = true;
        });

        // aqui detecta cuando se sueltan las teclas 
        window.addEventListener('keyup', (e) => {
            teclas[e.key] = false;
        });

        // Actualizar la posición del Mago en cada frame
        app.ticker.add(moverMago);
        } catch (error) {
            console.error('Error al cargar la imagen del Mago:', error);
        }
    }
