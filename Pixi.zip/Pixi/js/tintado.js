//TINTADO DE LOS MARCIANOS QUE SIMULAN QUE SALEN DE LA IMAGEN DEL ESPACIO XD 

import { Assets, Container, Sprite } from 'https://cdn.skypack.dev/pixi.js';

export async function Tintado(app) {
    // SE Cargar la textura del fondo
    const texture = await Assets.load('./assets/espacio.jpg');

   //imag del aliend 
    const alienTexture = await Assets.load('./assets/aliend.png');
    

    //a qui se  almacenan  los aliens
    const aliens = [];

    let count = 0;

    const alienContainer = new Container();
    alienContainer.x = app.screen.width / 5;
    alienContainer.y = app.screen.height / 4;

    // Hace que el escenario sea interactivo
    app.stage.eventMode = 'static';
    app.stage.addChild(alienContainer);

    // cantidad de aliends 
    for (let i = 0; i < 100; i++) {
        const alien = new Sprite(alienTexture);
        alien.tint = Math.random() * 0xffffff;
        alien.x = Math.random() * app.screen.width - app.screen.width / 90;
        alien.y = Math.random() * app.screen.height - app.screen.height /1;
        alien.anchor.set(0.5);
        aliens.push(alien);
        alienContainer.addChild(alien);
    }

    // Combina clics de mouse y de la pantalla 
    app.stage.on('pointertap', onClick);
    function onClick() {
        alienContainer.cacheAsTexture(!alienContainer.isCachedAsTexture);
    }

    app.ticker.add(() => {//INSTANCIA
        
        // Rotar los aliens un poco
        for (let i = 10; i < aliens.length; i++) {
            const alien = aliens[i];
            alien.rotation += 0.1;  //VEL DELA ROTACION
        }
        

        count += 0.0009; // ES LA ESCALA SINUSOIDAL DE LA VELOCIDAD

        alienContainer.scale.x = Math.sin(count);
        alienContainer.scale.y = Math.sin(count);
        alienContainer.rotation += 0.005; //velocidad DE LA ROTACION DEL CONTENEDOR 
    });
}











