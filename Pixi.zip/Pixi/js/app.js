import { Application } from 'https://cdn.skypack.dev/pixi.js';
import { crearFondo } from './fondo.js';
import { Fond1 } from './imag2.js'; // DEl mago 
import { Fond2 } from './imag3.js'; //IMAGEN DEL ESPACIO 
import { Fond3 } from './imag4.js';// IMAGEN DE LA LUCIERGANA 
import { TBasic } from './austrou.js'; //IMAGEN DEL AUSTRO
import { Tintado } from './tintado.js';//ALIEND
import { Star } from './star.js'; // Estrellas
import { CTextura } from './luna.js';
import { crearPersonaje } from './imagen1.js';
import * as PIXISound from 'https://cdn.skypack.dev/@pixi/sound'; // Importamos el  PIXI Sound 

(async () => {
    // se cra  la nueva aplicación
    const app = new Application();

    // Inicializar la aplicación
    await app.init({
        antialias: true, 
        resizeTo: window, 
    });

    // Añadir el canvas al documento
    document.body.appendChild(app.canvas);


    // Cargar el sonido 
    const backgroundSound = PIXISound.Sound.from({
        url: './assets/sonido.mp3',
        autoPlay: false, // No reproducir automáticamente
        loop: true, // sirve Repetir si es necesario
        volume: 0.1,
    });

    // cuando le des clic se activa el sonido (APP ES UN CONTENEDOR ) 
    app.stage.on('pointerdown', () => {
        if (!backgroundSound.isPlaying) {
            backgroundSound.play();
        }
    });

    // a qui es cuando le doy en la tecla enter se detenga la musica 
    window.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') { // cuando le pique enter 
            if (backgroundSound.isPlaying) {
                backgroundSound.stop(); // se detiene el sonido 
            }
        }
    });


    // Crear el fondo
    crearFondo(app);

    // Crear el jugador y su movimiento
    // crearPersonaje(app);

    // Crear fondos adicionales
    Fond1(app);
    Fond2(app);
    Fond3(app);
    crearPersonaje(app);
    // Crear otras funciones
    TBasic(app);
    Tintado(app);
    Star(app);
    CTextura(app);

})();


